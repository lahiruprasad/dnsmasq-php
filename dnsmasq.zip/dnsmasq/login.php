<?php 
session_start();
if (isset($_SESSION["user"])){
	header("location: admin.php");
	exit();
}
?>
<?php 
if (isset($_POST["username"]) && isset($_POST["password"])){
	
	$username=preg_replace('#[^A-Za-z0-9]#i',"",$_POST["username"]);
	$password=preg_replace('#[^A-Za-z0-9]#i',"",$_POST["password"]);
	
	include "db.php";
	
	$count="";
	$result = $admindb->query("SELECT * FROM logins WHERE username = '$username' AND password = '$password'");
	
	foreach ($result as $row) {
		if ( $row['username'] == $username ) {
			$count = 1;
		}
		else{
			$count = 0;
		}
	}

	if ($count == 1) {
    $_SESSION['loggedin'] = true;
    $_SESSION['loginFail'] = false;
    $_SESSION['user'] = $_POST['username'];
	header("location: admin.php");
	exit();
	}
	else{
		//echo 'That information is incorrect, try again <a href="login.php">Click Here</a>';
		echo "<font color='red'>Invalid Username or Password!</font>";
		//exit();
	}

}

?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Admin-Dnsmasq</title>
</head>

<body>
<div align="left" id="mainWrappers">
<div>
<form id="form1" name="form1" method="post" action="login.php">
Username:<br/>
  <input name="username" type="text" id=username" size="30" />
  <br/><br/>
Password:<br/>
	<input name="password" type="password" id="password" size="30" />
	<br/>
	<br/>
	<br/>

	<input type="submit" name="button" id="button" value="Log in"/>

</form>
<p>&nbsp;</p>
</div>
</div>
</body>
</html>

#!/bin/bash

sqlite3 "/var/www/html/dnsmasq/hosts.db" "select * from hosts order by host_name asc" | tr "|" " " > /etc/dnsmasq/hosts
sudo /etc/init.d/dnsmasq reload 2>&1

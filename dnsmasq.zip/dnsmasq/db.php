<?php

try {  
   $db = new PDO('sqlite:hosts.db');

} catch (PDOException $e) {
print $e->getMessage();
}
   $admindb = new PDO('sqlite:admin.db');
 
?>

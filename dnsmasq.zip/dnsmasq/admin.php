<?php 
session_start();
if (!isset($_SESSION["user"])){
	header("location: login.php");
	exit();
}

if (isset($_GET['logout'])) {
	unset($_SESSION["user"]);
	header("location: login.php");
	exit();
}

?>

<?php
include "db.php";

$edit_host_name = ".abc.local";
$edit_host_ip = "";

if(isset($_POST['index_to_edit']) && $_POST['index_to_edit']!=""){
	$edit_host_name=$_POST['index_to_edit'];
	$edit_host_ip=$_POST['index_to_edit_ip'];	

}
//remove from the list ////////

if(isset($_POST['index_to_remove']) && $_POST['index_to_remove']!=""){
	$key_to_remove=$_POST['index_to_remove'];
	//echo $key_to_remove;

	$sql =<<<EOF
      delete from hosts where host_name='$key_to_remove';
EOF;

	$db->query($sql);

	$event = "$key_to_remove deleted" ;
    	$time = date(DATE_RFC2822);
    	$user = $_SESSION['user'];

$sql =<<<EOF
      insert into history (event,time,user) values ("'$event'","'$time'","'$user'");
EOF;

$admindb->query($sql);

$message=shell_exec("/var/www/html/dnsmasq/update.sh 2>&1");
//print_r ($message);
}

if(isset($_POST['new_host_name']) && $_POST['new_host_name']!=""){
	
	$new_host_name=$_POST['new_host_name'];
	$new_host_ip=$_POST['new_host_ip'];
	//echo $key_to_remove;
		if (trim($new_host_name) == null OR trim($new_host_ip) == null) {
			echo "<font color='red'>Null values!</font>";
		}
		   elseif (!filter_var($new_host_ip, FILTER_VALIDATE_IP) === true) {
			echo "<font color='red'>Invalid IP address!</font>";
		}
		   elseif (strpos($new_host_name,'.abc.local') == false) {
			echo "<font color='red'>Invalid Hostname!</font>";
		}
			else {
	
	$sql =<<<EOF
      delete from hosts where host_name='$new_host_name';
EOF;
	$db->query($sql);	
				
	$sql =<<<EOF
      insert into hosts (host_name,host_ip) values ('$new_host_name','$new_host_ip');
EOF;
		$db->query($sql);
		
	$event = "$new_host_name newly added or updated" ;
    $time = date(DATE_RFC2822);
    $user = $_SESSION['user'];
	
	$sql =<<<EOF
      insert into history (event,time,user) values ("$event","$time","$user");
EOF;

$admindb->query($sql);

$message=shell_exec("/var/www/html/dnsmasq/update.sh 2>&1");
	
		}
}

$sql =<<<EOF
      select * from hosts order by host_name asc;
EOF;

$dynamicListHosts="";
$ret = $db->query($sql);

    foreach ($ret as $row) {
      //echo $row['host_name'] , "  " , $row['host_ip'] ;
		$host_name=$row['host_name'];
		$host_ip=$row['host_ip'];
		$dynamicListHosts.='<tr>';
		$dynamicListHosts.='<td>' .$host_name.'</td>';
		$dynamicListHosts.='<td>' .$host_ip.'</td>';
		$dynamicListHosts.='<td> <form action="admin.php" method="post" onsubmit="return confirm(\'Confirm delete !\');"><input name="deleteBtn' . $host_name . ' " title="Delete entry" type="submit" value="x" /><input name="index_to_remove" type="hidden" value="' . $host_name . '"/></form></td>';
		$dynamicListHosts.='<td> <form action="admin.php" method="post"><input name="editBtn' . $host_name . ' " title="Edit entry" type="submit" value="e""/><input name="index_to_edit" type="hidden" value="' . $host_name . '"/><input name="index_to_edit_ip" type="hidden" value="' . $host_ip . '"/></form></td>';
		$dynamicListHosts.='</tr>';
   }
  
//unset($db);

?>

<html>
<Title>Admin-Dnsmasq</Title>
<body>
<style>
table{table-layout:fixed;}
td{width:1px;white-space:nowrap;}
</style>
<div><a href="admin.php?logout=true">Logout</a></div>
<br>
<br>
<form name="form_add_new" method="post" action="admin.php">
<label for="new_host_name">Hostname</label>
<input type='text' style="text-align:right;" name='new_host_name' id='new_host_name' value="<?php echo $edit_host_name;?>"/>
<label for="new_host_ip">IP Address</label>
<input type='text' name='new_host_ip' id='new_host_ip' value="<?php echo $edit_host_ip;?>" />
<input type="submit" title="To add a new entry: enter correct Hostname and IP, To edit an entry: click on edit button and change the IP here." name="submit" value="Add/Update entry"/>
</form>

    <table border=1>
	  <tr>
        <td width="100%" align="center" bgcolor="#999999"><strong>Hostname</strong></td>
        <td width="100%" align="center" bgcolor="#999999"><strong>IP Address</strong></td>
		<td width="100%" align="center" bgcolor="#999999"><strong></strong></td>
		<td width="100%" align="center" bgcolor="#999999"><strong></strong></td>
	  </tr>
<?php echo $dynamicListHosts;?>
    </table>

</body>
</html>
